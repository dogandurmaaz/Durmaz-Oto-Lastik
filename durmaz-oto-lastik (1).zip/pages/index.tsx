import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Hero Section */}
      <div className="relative w-full h-[500px] flex items-center justify-center bg-black text-white">
        <Image
          src="/dda.jpg"
          alt="Yol Yardım"
          layout="fill"
          objectFit="cover"
          className="opacity-60"
        />
        <div className="relative z-10 text-center px-4">
          <Image
            src="/logo.png"
            alt="Durmaz Oto Lastik Logo"
            width={120}
            height={120}
            className="mx-auto mb-4"
          />
          <h1 className="text-4xl font-bold mb-2">
            Durmaz Oto Lastik Varken Durmak Yok, Yola Devam!
          </h1>
          <p className="text-lg">7/24 Lastik Yol Yardım Hizmeti</p>
          <p className="text-xl font-semibold mt-4">📞 0542 187 88 54</p>
        </div>
      </div>

      {/* Servis Bölgeleri */}
      <section className="py-12 px-6 text-center">
        <h2 className="text-3xl font-bold mb-6">Servis Bölgeleri</h2>
        <p className="max-w-2xl mx-auto text-lg">
          Sakarya, Anadolu Otoyolu, Kuzey Marmara Otoyolu, Adapazarı, Erenler,
          Serdivan, Sapanca, Akyazı, Hendek, Karasu, Pamukova, Geyve, Söğütlü,
          Ferizli
        </p>
      </section>
    </div>
  );
}
